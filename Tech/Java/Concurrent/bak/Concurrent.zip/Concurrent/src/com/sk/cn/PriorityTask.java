package com.sk.cn;

import java.util.Random;

public class PriorityTask implements Runnable,Comparable<PriorityTask>{
	private int priority;
	private String name;
	public PriorityTask(int pri,String name){
		this.priority = pri;
		this.name = name;
	}
	@Override
	public int compareTo(PriorityTask bef) {
		if(bef.priority > this.priority){
			return 1;
		}
		else{
			return -1;
		}
	}

	@Override
	public void run() {
		Random random=new Random();
		try {
			Thread.sleep(random.nextInt(10000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(name + " Finish!");
	}

}
