package com.sk.cn;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadPoolTest {
	public static void main(String[] args) throws InterruptedException {
		ThreadPoolExecutor executor = new ThreadPoolExecutor(2, 2, 6,
				TimeUnit.SECONDS, new PriorityBlockingQueue<Runnable>());

		for (int i = 1; i < 8; i++) {
			executor.execute(new PriorityTask(1, "Task-" + i));
		}

		for (int i = 0; i < 5; i++) {
			showLog(executor);
			TimeUnit.SECONDS.sleep(1);

		}

		// 9. ʹ�� shutdown() �����ر�ִ���ߡ�
		executor.shutdown();

		// 10. ����������Ϊ5��forѭ������ÿ��������ִ���ߵ��� showLog() ����д�����Ϣ�������߳�����1�롣
		for (int i = 0; i < 5; i++) {
			showLog(executor);
			TimeUnit.SECONDS.sleep(1);
		}
		executor.awaitTermination(1, TimeUnit.DAYS);
		showLog(executor);
		System.out.printf("Main: End of the program.\n");
	}
	
	private static void showLog(ThreadPoolExecutor executor) {
		System.out.printf("*********************");
		System.out.printf("Main: Executor Log");
		System.out.printf("Main: Executor: Core Pool Size:%d\n",executor.getCorePoolSize());
		System.out.printf("Main: Executor: Pool Size: %d\n",executor. getPoolSize());
		System.out.printf("Main: Executor: Active Count:%d\n",executor.getActiveCount());
		System.out.printf("Main: Executor: Task Count: %d\n",executor. getTaskCount());
		System.out.printf("Main: Executor: Completed Task Count:%d\n",executor.getCompletedTaskCount());
		System.out.printf("Main: Executor: Shutdown: %s\n",executor. isShutdown());
		System.out.printf("Main: Executor: Terminating:%s\n",executor.isTerminating());
		System.out.printf("Main: Executor: Terminated: %s\n",executor. isTerminated());
		System.out.printf("*********************\n");
		}

}
